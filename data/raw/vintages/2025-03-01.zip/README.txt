-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:30 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20250228   Unemployment Rate Vintage: 2025-02-28, Percent, Monthly, Seasonally    Data Updated: 2025-02-07
                  Adjusted
PCEPI_20250228    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2025-02-28
                  2025-02-28, Index 2017=100, Monthly, Seasonally Adjusted
GDPC1_20250228    Real Gross Domestic Product Vintage: 2025-02-28, Billions of Chained   Data Updated: 2025-02-27
                  2017 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20250228  Real Disposable Personal Income Vintage: 2025-02-28, Billions of       Data Updated: 2025-02-28
                  Chained 2017 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20250228  University of Michigan: Consumer Sentiment Vintage: 2025-02-28, Index  Data Updated: 2025-03-28
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

