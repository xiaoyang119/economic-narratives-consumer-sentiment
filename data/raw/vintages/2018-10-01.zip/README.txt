-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:30 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20180930   Civilian Unemployment Rate Vintage: 2018-09-30, Percent, Monthly,      Data Updated: 2018-09-07
                  Seasonally Adjusted
PCEPI_20180930    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2018-09-28
                  2018-09-30, Index 2012=100, Monthly, Seasonally Adjusted
GDPC1_20180930    Real Gross Domestic Product Vintage: 2018-09-30, Billions of Chained   Data Updated: 2018-09-27
                  2012 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20180930  Real Disposable Personal Income Vintage: 2018-09-30, Billions of       Data Updated: 2018-09-28
                  Chained 2012 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20180930  University of Michigan: Consumer Sentiment Vintage: 2018-09-30, Index  Data Updated: 2018-10-26
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

