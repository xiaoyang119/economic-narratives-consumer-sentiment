-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:29 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20110630   Civilian Unemployment Rate Vintage: 2011-06-30, Percent, Monthly,      Data Updated: 2011-06-03
                  Seasonally Adjusted
PCEPI_20110630    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2011-06-27
                  2011-06-30, Index 2005=100, Monthly, Seasonally Adjusted
GDPC1_20110630    Real Gross Domestic Product Vintage: 2011-06-30, Billions of Chained   Data Updated: 2011-06-24
                  2005 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20110630  Real Disposable Personal Income Vintage: 2011-06-30, Billions of       Data Updated: 2011-06-27
                  Chained 2005 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20110630  University of Michigan: Consumer Sentiment Vintage: 2011-06-30, Index  Data Updated: 2012-09-28
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

