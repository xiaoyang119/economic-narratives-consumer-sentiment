-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:30 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20210831   Unemployment Rate Vintage: 2021-08-31, Percent, Monthly, Seasonally    Data Updated: 2021-08-06
                  Adjusted
PCEPI_20210831    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2021-08-27
                  2021-08-31, Index 2012=100, Monthly, Seasonally Adjusted
GDPC1_20210831    Real Gross Domestic Product Vintage: 2021-08-31, Billions of Chained   Data Updated: 2021-08-26
                  2012 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20210831  Real Disposable Personal Income Vintage: 2021-08-31, Billions of       Data Updated: 2021-08-27
                  Chained 2012 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20210831  University of Michigan: Consumer Sentiment Vintage: 2021-08-31, Index  Data Updated: 2021-10-01
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

