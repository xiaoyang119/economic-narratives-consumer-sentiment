-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:30 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20260430   Unemployment Rate Vintage: 2026-04-30, Percent, Monthly, Seasonally    Data Updated: 2026-04-03
                  Adjusted
PCEPI_20260430    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2026-04-30
                  2026-04-30, Index 2017=100, Monthly, Seasonally Adjusted
GDPC1_20260430    Real Gross Domestic Product Vintage: 2026-04-30, Billions of Chained   Data Updated: 2026-04-30
                  2017 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20260430  Real Disposable Personal Income Vintage: 2026-04-30, Billions of       Data Updated: 2026-04-30
                  Chained 2017 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20260430  University of Michigan: Consumer Sentiment Vintage: 2026-04-30, Index  Data Updated: 2026-05-22
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

