-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:29 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20141130   Civilian Unemployment Rate Vintage: 2014-11-30, Percent, Monthly,      Data Updated: 2014-11-07
                  Seasonally Adjusted
PCEPI_20141130    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2014-11-26
                  2014-11-30, Index 2009=100, Monthly, Seasonally Adjusted
GDPC1_20141130    Real Gross Domestic Product Vintage: 2014-11-30, Billions of Chained   Data Updated: 2014-11-25
                  2009 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20141130  Real Disposable Personal Income Vintage: 2014-11-30, Billions of       Data Updated: 2014-11-26
                  Chained 2009 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20141130  University of Michigan: Consumer Sentiment Vintage: 2014-11-30, Index  Data Updated: 2015-06-01
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

