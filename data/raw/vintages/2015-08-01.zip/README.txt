-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:29 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20150731   Civilian Unemployment Rate Vintage: 2015-07-31, Percent, Monthly,      Data Updated: 2015-07-02
                  Seasonally Adjusted
PCEPI_20150731    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2015-06-25
                  2015-07-31, Index 2009=100, Monthly, Seasonally Adjusted
GDPC1_20150731    Real Gross Domestic Product Vintage: 2015-07-31, Billions of Chained   Data Updated: 2015-07-30
                  2009 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20150731  Real Disposable Personal Income Vintage: 2015-07-31, Billions of       Data Updated: 2015-06-25
                  Chained 2009 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20150731  University of Michigan: Consumer Sentiment Vintage: 2015-07-31, Index  Data Updated: 2016-01-04
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

