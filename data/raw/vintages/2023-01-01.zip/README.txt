-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:30 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20221231   Unemployment Rate Vintage: 2022-12-31, Percent, Monthly, Seasonally    Data Updated: 2022-12-02
                  Adjusted
PCEPI_20221231    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2022-12-23
                  2022-12-31, Index 2012=100, Monthly, Seasonally Adjusted
GDPC1_20221231    Real Gross Domestic Product Vintage: 2022-12-31, Billions of Chained   Data Updated: 2022-12-22
                  2012 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20221231  Real Disposable Personal Income Vintage: 2022-12-31, Billions of       Data Updated: 2022-12-23
                  Chained 2012 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20221231  University of Michigan: Consumer Sentiment Vintage: 2022-12-31, Index  Data Updated: 2023-01-27
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

