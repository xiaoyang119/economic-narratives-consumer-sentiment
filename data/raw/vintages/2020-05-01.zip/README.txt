-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:30 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20200430   Unemployment Rate Vintage: 2020-04-30, Percent, Monthly, Seasonally    Data Updated: 2020-04-03
                  Adjusted
PCEPI_20200430    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2020-04-30
                  2020-04-30, Index 2012=100, Monthly, Seasonally Adjusted
GDPC1_20200430    Real Gross Domestic Product Vintage: 2020-04-30, Billions of Chained   Data Updated: 2020-04-29
                  2012 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20200430  Real Disposable Personal Income Vintage: 2020-04-30, Billions of       Data Updated: 2020-04-30
                  Chained 2012 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20200430  University of Michigan: Consumer Sentiment Vintage: 2020-04-30, Index  Data Updated: 2020-05-29
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

