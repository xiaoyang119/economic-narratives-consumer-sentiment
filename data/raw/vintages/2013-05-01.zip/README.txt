-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:29 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20130430   Civilian Unemployment Rate Vintage: 2013-04-30, Percent, Monthly,      Data Updated: 2013-04-05
                  Seasonally Adjusted
PCEPI_20130430    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2013-04-29
                  2013-04-30, Index 2005=100, Monthly, Seasonally Adjusted
GDPC1_20130430    Real Gross Domestic Product Vintage: 2013-04-30, Billions of Chained   Data Updated: 2013-04-26
                  2005 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20130430  Real Disposable Personal Income Vintage: 2013-04-30, Billions of       Data Updated: 2013-04-29
                  Chained 2005 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20130430  University of Michigan: Consumer Sentiment Vintage: 2013-04-30, Index  Data Updated: 2013-11-06
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

