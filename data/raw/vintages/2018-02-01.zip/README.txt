-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:30 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20180131   Civilian Unemployment Rate Vintage: 2018-01-31, Percent, Monthly,      Data Updated: 2018-01-05
                  Seasonally Adjusted
PCEPI_20180131    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2018-01-29
                  2018-01-31, Index 2009=100, Monthly, Seasonally Adjusted
GDPC1_20180131    Real Gross Domestic Product Vintage: 2018-01-31, Billions of Chained   Data Updated: 2018-01-26
                  2009 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20180131  Real Disposable Personal Income Vintage: 2018-01-31, Billions of       Data Updated: 2018-01-29
                  Chained 2009 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20180131  University of Michigan: Consumer Sentiment Vintage: 2018-01-31, Index  Data Updated: 2018-03-29
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

