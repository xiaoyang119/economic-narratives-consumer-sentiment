-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:30 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20221130   Unemployment Rate Vintage: 2022-11-30, Percent, Monthly, Seasonally    Data Updated: 2022-11-04
                  Adjusted
PCEPI_20221130    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2022-10-28
                  2022-11-30, Index 2012=100, Monthly, Seasonally Adjusted
GDPC1_20221130    Real Gross Domestic Product Vintage: 2022-11-30, Billions of Chained   Data Updated: 2022-11-30
                  2012 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20221130  Real Disposable Personal Income Vintage: 2022-11-30, Billions of       Data Updated: 2022-10-28
                  Chained 2012 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20221130  University of Michigan: Consumer Sentiment Vintage: 2022-11-30, Index  Data Updated: 2022-12-23
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

