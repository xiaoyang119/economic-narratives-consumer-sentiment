-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:29 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20150228   Civilian Unemployment Rate Vintage: 2015-02-28, Percent, Monthly,      Data Updated: 2015-02-06
                  Seasonally Adjusted
PCEPI_20150228    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2015-02-02
                  2015-02-28, Index 2009=100, Monthly, Seasonally Adjusted
GDPC1_20150228    Real Gross Domestic Product Vintage: 2015-02-28, Billions of Chained   Data Updated: 2015-02-27
                  2009 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20150228  Real Disposable Personal Income Vintage: 2015-02-28, Billions of       Data Updated: 2015-02-02
                  Chained 2009 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20150228  University of Michigan: Consumer Sentiment Vintage: 2015-02-28, Index  Data Updated: 2015-08-31
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

