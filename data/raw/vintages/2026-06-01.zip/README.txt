-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:30 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20260531   Unemployment Rate Vintage: 2026-05-31, Percent, Monthly, Seasonally    Data Updated: 2026-05-08
                  Adjusted
PCEPI_20260531    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2026-05-28
                  2026-05-31, Index 2017=100, Monthly, Seasonally Adjusted
GDPC1_20260531    Real Gross Domestic Product Vintage: 2026-05-31, Billions of Chained   Data Updated: 2026-05-28
                  2017 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20260531  Real Disposable Personal Income Vintage: 2026-05-31, Billions of       Data Updated: 2026-05-28
                  Chained 2017 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20260531  University of Michigan: Consumer Sentiment Vintage: 2026-05-31, Index  Data Updated: 2026-06-26
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

