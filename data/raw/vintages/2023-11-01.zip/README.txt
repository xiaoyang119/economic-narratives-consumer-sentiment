-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:30 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20231031   Unemployment Rate Vintage: 2023-10-31, Percent, Monthly, Seasonally    Data Updated: 2023-10-06
                  Adjusted
PCEPI_20231031    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2023-10-27
                  2023-10-31, Index 2017=100, Monthly, Seasonally Adjusted
GDPC1_20231031    Real Gross Domestic Product Vintage: 2023-10-31, Billions of Chained   Data Updated: 2023-10-26
                  2017 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20231031  Real Disposable Personal Income Vintage: 2023-10-31, Billions of       Data Updated: 2023-10-27
                  Chained 2017 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20231031  University of Michigan: Consumer Sentiment Vintage: 2023-10-31, Index  Data Updated: 2023-11-22
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

