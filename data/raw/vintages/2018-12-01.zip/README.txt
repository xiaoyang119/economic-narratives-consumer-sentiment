-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:30 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20181130   Civilian Unemployment Rate Vintage: 2018-11-30, Percent, Monthly,      Data Updated: 2018-11-02
                  Seasonally Adjusted
PCEPI_20181130    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2018-11-29
                  2018-11-30, Index 2012=100, Monthly, Seasonally Adjusted
GDPC1_20181130    Real Gross Domestic Product Vintage: 2018-11-30, Billions of Chained   Data Updated: 2018-11-28
                  2012 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20181130  Real Disposable Personal Income Vintage: 2018-11-30, Billions of       Data Updated: 2018-11-29
                  Chained 2012 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20181130  University of Michigan: Consumer Sentiment Vintage: 2018-11-30, Index  Data Updated: 2018-12-21
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

