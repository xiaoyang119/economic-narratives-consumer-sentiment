-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:30 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20180731   Civilian Unemployment Rate Vintage: 2018-07-31, Percent, Monthly,      Data Updated: 2018-07-06
                  Seasonally Adjusted
PCEPI_20180731    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2018-07-31
                  2018-07-31, Index 2012=100, Monthly, Seasonally Adjusted
GDPC1_20180731    Real Gross Domestic Product Vintage: 2018-07-31, Billions of Chained   Data Updated: 2018-07-27
                  2012 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20180731  Real Disposable Personal Income Vintage: 2018-07-31, Billions of       Data Updated: 2018-07-31
                  Chained 2012 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20180731  University of Michigan: Consumer Sentiment Vintage: 2018-07-31, Index  Data Updated: 2018-09-07
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

