-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:29 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20100930   Civilian Unemployment Rate Vintage: 2010-09-30, Percent, Monthly,      Data Updated: 2010-09-03
                  Seasonally Adjusted
PCEPI_20100930    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2010-08-30
                  2010-09-30, Index 2005=100, Monthly, Seasonally Adjusted
GDPC1_20100930    Real Gross Domestic Product Vintage: 2010-09-30, Billions of Chained   Data Updated: 2010-09-30
                  2005 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20100930  Real Disposable Personal Income Vintage: 2010-09-30, Billions of       Data Updated: 2010-08-30
                  Chained 2005 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20100930  University of Michigan: Consumer Sentiment Vintage: 2010-09-30, Index  Data Updated: 2012-09-28
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

