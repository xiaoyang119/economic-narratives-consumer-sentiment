-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:30 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20170228   Civilian Unemployment Rate Vintage: 2017-02-28, Percent, Monthly,      Data Updated: 2017-02-03
                  Seasonally Adjusted
PCEPI_20170228    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2017-01-30
                  2017-02-28, Index 2009=100, Monthly, Seasonally Adjusted
GDPC1_20170228    Real Gross Domestic Product Vintage: 2017-02-28, Billions of Chained   Data Updated: 2017-02-28
                  2009 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20170228  Real Disposable Personal Income Vintage: 2017-02-28, Billions of       Data Updated: 2017-01-30
                  Chained 2009 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20170228  University of Michigan: Consumer Sentiment Vintage: 2017-02-28, Index  Data Updated: 2017-03-10
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

