-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:29 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20141031   Civilian Unemployment Rate Vintage: 2014-10-31, Percent, Monthly,      Data Updated: 2014-10-03
                  Seasonally Adjusted
PCEPI_20141031    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2014-10-31
                  2014-10-31, Index 2009=100, Monthly, Seasonally Adjusted
GDPC1_20141031    Real Gross Domestic Product Vintage: 2014-10-31, Billions of Chained   Data Updated: 2014-10-30
                  2009 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20141031  Real Disposable Personal Income Vintage: 2014-10-31, Billions of       Data Updated: 2014-10-31
                  Chained 2009 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20141031  University of Michigan: Consumer Sentiment Vintage: 2014-10-31, Index  Data Updated: 2015-04-27
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

