-------------------------------------------------------------------
ALFRED Graph Observations
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-14 4:29 pm CDT
-------------------------------------------------------------------

----------------  ---------------------------------------------------------------------  ------------------------
UNRATE_20111031   Civilian Unemployment Rate Vintage: 2011-10-31, Percent, Monthly,      Data Updated: 2011-10-07
                  Seasonally Adjusted
PCEPI_20111031    Personal Consumption Expenditures: Chain-type Price Index Vintage:     Data Updated: 2011-10-28
                  2011-10-31, Index 2005=100, Monthly, Seasonally Adjusted
GDPC1_20111031    Real Gross Domestic Product Vintage: 2011-10-31, Billions of Chained   Data Updated: 2011-10-27
                  2005 Dollars, Quarterly, Seasonally Adjusted Annual Rate
DSPIC96_20111031  Real Disposable Personal Income Vintage: 2011-10-31, Billions of       Data Updated: 2011-10-28
                  Chained 2005 Dollars, Monthly, Seasonally Adjusted Annual Rate
UMCSENT_20111031  University of Michigan: Consumer Sentiment Vintage: 2011-10-31, Index  Data Updated: 2012-09-28
                  1966:Q1=100, Monthly, Not Seasonally Adjusted
----------------  ---------------------------------------------------------------------  ------------------------

